# DomainEventsConsole

A console app showing domain events in action using .NET 5
